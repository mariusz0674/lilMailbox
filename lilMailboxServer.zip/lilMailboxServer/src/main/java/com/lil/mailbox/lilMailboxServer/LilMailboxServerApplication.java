package com.lil.mailbox.lilMailboxServer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LilMailboxServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(LilMailboxServerApplication.class, args);
	}

}
