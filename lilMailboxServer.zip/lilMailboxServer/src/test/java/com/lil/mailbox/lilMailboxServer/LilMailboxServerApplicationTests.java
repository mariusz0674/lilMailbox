package com.lil.mailbox.lilMailboxServer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LilMailboxServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
